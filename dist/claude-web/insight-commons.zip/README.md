# insight-commons

**현장 경험을 남이 쓸 수 있는 지식으로 만들고, 남의 지식을 내 조건에서 검증해 받아들이는 Claude 스킬.**

독점 데이터베이스의 대안이 더 큰 독점 데이터베이스일 필요는 없다.
**여럿이 각자 겪은 것을 검증 가능한 형태로 쌓는 것**이다.

그러려면 지식을 만드는 방식 자체가 공개되고 재현 가능해야 한다.
이 스킬이 그 방식이다.

[`owner-lens`](../owner-lens)와 짝을 이룬다. owner-lens가 회사 하나를 분석한다면,
이것은 그 분석에서 나온 배움을 **공유재로 만든다.**

---

## 푸는 문제 다섯

1. **1회 관찰을 법칙으로 착각한다** — 사람은 한 번 겪은 걸 바로 일반화한다
2. **공유하면 회사가 특정된다** — 그래서 선뜻 내놓기 어렵다
3. **남의 노하우가 내게 통할지 모른다** — 조건이 다른데 그대로 가져다 쓴다
4. **반례가 나오면 그냥 버린다** — 조건을 좁힐 기회를 놓친다
5. **낡은 지식이 계속 굴러다닌다** — 언제 폐기할지 아무도 안 정한다

---

## 핵심 규칙 하나

> **남의 `[확인됨]`은 내게 `[미검증]`이다.**

남이 세 번 확인했다는 건 **그 사람 조건에서** 세 번이다.
조건이 다르면 그 확인은 이월되지 않는다.

이게 이 스킬 전체를 관통하는 원칙이다.
그래서 반입(A) 모드가 5단계 판정을 밟는다.

---

## 모드

| | 모드 | 언제 |
|---|---|---|
| **R** | 기록 | 방금 겪은 것을 항목으로 만든다 |
| **P** | 승격 | 쌓인 관찰의 검증 등급을 올릴지 판정 |
| **A** | **반입** ★ | 남의 항목을 내 조건에서 쓸 수 있는지 판정 |
| **M** | 병합 | 반례가 나왔을 때. 버리는 대신 조건을 좁힌다 |
| **D** | 정리 | 낡은 항목 점검과 폐기 |
| **X** | 공개 | 탈식별화해서 공유 묶음으로 내보낸다 |

---

## 원장 항목의 다섯 칸

| 칸 | 비면 생기는 일 |
|---|---|
| 조건 | 아무 데나 갖다 쓴다 |
| 관찰 | 주장만 남는다 |
| **메커니즘** | **전이 판정을 못 한다** |
| 전이 범위 | 과일반화된다 |
| 검증 상태 | 1회를 법칙으로 쓴다 |

> 메커니즘 칸이 제일 자주 비고, 제일 치명적이다.
> "왜 그런지는 모르지만 그렇더라"는 기록으로는 남길 수 있지만
> **남에게 전이시킬 수 없다.** 설명 없는 상관은 조건이 바뀌면 깨진다.

---

## 설치

1. 이 폴더를 통째로 받는다
2. 압축해 Claude 설정의 스킬(Capabilities)에 올린다
3. 채팅에서 경험 정리 얘기를 꺼내면 자동으로 뜬다. `/insight-commons`로 직접 불러도 된다

챗에서 돌기 때문에 **원장은 사용자가 보관한다.**
대화 시작할 때 기존 원장을 붙여 넣고, 끝날 때 갱신본을 받아 저장한다.

---

## 구조

```
SKILL.md                     진입점. 모드 · 문답 · 규칙
PHILOSOPHY.md                왜 이렇게 설계했나 (owner-lens와 공유)
references/
  transfer.md                ★ 반입 판정 5단계 — 이 스킬의 핵심
  lifecycle.md               승격 · 반례 · 낡음 · 폐기
  deident.md                 탈식별화와 공개 묶음
templates/
  entry.md                   항목 서식과 채우는 요령
```

---

## 다른 지식 관리 도구와 다른 점

- **반례를 지우지 않는다.** `[반증됨]`도 남긴다. 같은 실수를 다시 하지 않게 막아 준다
- **`[반증됨]`이 하나도 없으면 경고한다.** 반례를 안 찾은 것으로 본다
- **남의 검증 등급을 물려받지 않는다.** 반입은 항상 `[미검증]`부터 시작한다
- **메커니즘 없는 항목은 전이시키지 않는다.** 기록은 남기되 남에게 넘기지 않는다
- **지식마다 유통기한이 다르다.** 기술 12개월, 제도 24개월, 사람 행동 60개월

---

## 한계

- 검증 등급의 기준(2회 잠정, 3회 확인)은 **경험칙이지 통계적 유의성이 아니다.**
- 한 사람이 쓰는 원장은 그 사람의 위치에 편중된다.
  「이 묶음의 한계」를 반드시 적는 이유가 그것이다.
- 탈식별화가 안 되는 항목은 못 내놓는다. 그건 그대로 두는 게 맞다.

---

## 기여

되돌려 주는 흐름이 있어야 이 프로젝트가 성립한다.

- 반입해서 검증했으면 **원 출처에 알린다.** 확인이든 반례든
- **반례가 더 값지다.** 조건을 좁힐 수 있게 해 준다
- 묶음을 내놓을 때 `[반증됨]` 항목도 함께 넣는다. 빼면 생존 편향이 된다

**라이선스: 미정.** 비영리·오픈소스로 풀 예정.

---

## English

**insight-commons** turns field experience into knowledge other people can
check, and tells you whether someone else's hard-won lesson actually applies to
your situation before you act on it.

One rule runs through everything:

> **Someone else's `[confirmed]` is your `[unverified]`.**

Three confirmations under their conditions don't carry over to yours. Adopting
a lesson starts at zero and works its way up again.

Two more rules do most of the work:

- **Counterexamples are never deleted.** They narrow the conditions instead, which
  usually makes the entry more accurate than it was.
- **An entry with no stated mechanism can be recorded but never passed on.**
  A correlation nobody can explain breaks the moment conditions change, and you
  won't know why.
