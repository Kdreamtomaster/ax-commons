# tuning — 고칠 곳은 여기 하나다

이 파일만 고치면 된다. 나머지는 방법론이라 건드릴 일이 거의 없다.

챗에서 쓰는 스킬이라 런타임에 이 파일을 바꿀 수는 없다.
**받아서 고친 뒤 다시 올리는** 방식으로 쓴다.
한 번만 쓸 값이면 파일을 고치지 말고 대화에서 그냥 말해도 된다.

---

## 1. 내 쪽 정보

미리 적어 두면 매번 안 물어본다. 비워 두면 R0에서 묻는다.

```yaml
me:
  role: ""                    # 예: 프리세일즈 / 사업개발 / 컨설턴트 / 창업자
  what_we_sell: ""            # 팔 수 있는 것
  what_we_cannot_support: ""  # ★ 비워 두지 말 것
  authority_limit: ""         # 내가 그 자리에서 약속할 수 있는 범위
```

> `what_we_cannot_support`가 비면 반드시 과잉 약속이 나온다.
> 스킬은 이 값이 비면 R0에서 먼저 묻는다.

---

## 2. 임기 게이트 임계값

S7에서 쓴다. 산업·직급 관행에 따라 조정한다.

```yaml
tenure_gate:
  safe_ratio: 0.6        # 회수기간 < 잔여임기 × 이 값 → "팔린다"
  risk_band: 1.0         # 회수기간 ≈ 잔여임기 → "후임자 리스크"
  default_tenure_years:  # 잔여 임기를 모를 때 쓰는 기본값
    c_level: 3
    executive: 2
    team_lead: 3
    owner: 10            # 오너는 임기 개념이 약하다
```

**조정 감각**

- 인사이동이 잦은 조직이면 `safe_ratio`를 0.4~0.5로 내린다
- 오너 경영이고 오너를 직접 만난다면 게이트를 느슨하게 봐도 된다
- PE 보유면 임기가 아니라 **회수 시점**이 기준이다. 잔여 임기 자리에 회수까지 남은 기간을 넣는다

---

## 3. 출력

```yaml
output:
  language: "ko"          # ko | en
  tone: "신중한 B2B"       # 단문 위주. 확약 표현 금지
  detail: "standard"      # brief | standard | deep
  hypotheses_count: 3     # S8 가설 개수
  max_questions: 4        # 라운드당 질문 상한
```

`brief`는 「한 장 요약 + 개입 판정표 + 미팅 가설」만 낸다. 미팅 직전에 쓴다.

---

## 4. 문답 진행

```yaml
intake:
  draft_first: true       # ★ R1에서 틀린 초안을 먼저 낼지
  rounds_max: 4
  allow_skip: true        # "모름" / "건너뛰기" 허용
  show_progress: true     # [2/4 라운드] 표시
```

> `draft_first`를 끄면 순수 질문형이 된다. **끄지 않기를 권한다.**
> 사람은 빈칸을 채우기보다 틀린 것을 고치기를 훨씬 쉽게 한다.

---

## 5. 산업 마진 스프레드 참조 (선택)

S5에서 쓴다. **비워 두어도 된다.** 비면 `[모름]`으로 처리하고 진행한다.

적어 두면 분석이 날카로워지지만 **숫자는 낡는다.** 출처와 연도를 반드시 함께 적는다.

```yaml
margin_reference:
  - industry: ""
    year: ""
    source: ""
    operating_margin:
      top: ""
      median: ""
      bottom: ""
    swing_factors: ["", "", ""]   # 상·하위를 가르는 운영 변수
```

예시 형식 (값은 각자 채운다):

```yaml
  - industry: "전자부품 제조"
    year: "2025"
    source: "한국은행 기업경영분석"
    operating_margin: { top: "", median: "", bottom: "" }
    swing_factors: ["불량 재작업률", "설비 가동률", "수주 예측 정확도"]
```

---

## 6. 신호 해석 규칙 추가

`references/pipeline.md`의 채용공고 해석표에 자기 산업 규칙을 덧붙일 수 있다.

```yaml
custom_signals:
  - observation: ""    # 무엇을 봤을 때
    reading: ""        # 어떻게 읽는가
    confidence: ""     # 사실 / 추론 / 가설
```

---

## 7. 안 고치는 게 좋은 것

아래는 이 스킬을 이 스킬이게 하는 부분이다. 고치면 다른 도구가 된다.

- **뻔한 답 게이트** — 빼면 일반론이 돌아온다
- **근거 등급 표기** — 빼면 추측과 사실이 섞인다
- **`[불가]` 판정을 반드시 남기는 규칙** — 빼면 낙관 편향이 된다
- **"남은 모름"을 필수 산출로 두는 규칙** — 빼면 창작이 된다
- **인사이트 원장의 특정 가능성 점검** — 빼면 기밀이 샌다
